module.exports = {
    portExpress: 5000,
    nameDatabase: "unimedicDB"
  };